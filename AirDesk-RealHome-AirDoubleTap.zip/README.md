# AirDesk Real Home
Shows real installed launcher apps dynamically. Finger movement highlights an app; two quick air finger movements launch it. No pinch gesture. Set AirDesk as the Android Home/Launcher app after installing the APK.
